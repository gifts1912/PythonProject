s = set([1, 2, 2, 3, 3, 4, 5])
print(s)
s = set((2, 3, 4, 5, 6, 2, 1, 9))
print(s)
